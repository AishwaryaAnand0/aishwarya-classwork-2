/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int fibonacci(int num)
{
   
    if (num == 0)
    {
        return 0; 
    }
    else if (num == 1)
    {
        return 1; 
    }
    else
    {
        return fibonacci(num - 1) + fibonacci(num - 2); 
    }
}

int main()
{
    int num;
    printf("Enter the number of elements to be in the series : ");
    scanf("%d", &num); 
    for (int i = 0; i < num; i++)
    {
        printf("%d, ", fibonacci(i)); 
    }
    return 0;
}
