/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int  main( )
{
int  a[25], n, i ;
printf(" Enter the Numbers of Array Element: ") ;
scanf("%d ",& n) ;
printf("\n Enter the Array Element : \n") ;
for (  i = 1 ; i < n ; i++)
{
scanf("%d ",& a[i]) ;
}
printf("\n Array Elements are : \n ") ;
for (  i = 1 ; i <  n ; i++)
{
printf("\t %d ",a[i]) ;
}
return 0;
}

