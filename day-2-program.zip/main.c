/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include<stdio.h>
int main()
{
    char operation;
    double n1,n2;
    printf("enter an operator(+,-,*,/)");
    scanf("%c",&operation);
    printf("enter two operands");
    scanf("%if%if",&n1,&n2);
    switch(operation)
    {
        case'+':
        printf("%1if+%1if=%1if",n1,n2,n1+n2);
        break;
        case'*':
        printf("%1if*%1if=%1if",n1,n2,n1*n2);
        break;
        case'-':
        printf("%1if-%1if=%1if",n1,n2,n1-n2);
        break;
        case'/':
        printf("%1if/%1if=%1if",n1,n2,n1/n2);
        break;
        default:
        printf("error!operator is not correct");
    }
    return 0;

        
    
}